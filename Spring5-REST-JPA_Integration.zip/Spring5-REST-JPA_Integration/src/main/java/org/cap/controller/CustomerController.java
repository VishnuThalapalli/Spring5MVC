package org.cap.controller;

import java.util.List;

import org.cap.dao.ICustomerDao;
import org.cap.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/cust")
public class CustomerController {

	@Autowired
	private ICustomerDao customerDao;

	@PostMapping("/customers")
	public ResponseEntity<List<Customer>> createCustomer(@RequestBody Customer customer) {
		List<Customer> customers = customerDao.createCustomer(customer);
		if (customers == null || customers.isEmpty()) {
			return new ResponseEntity("Sorry! Customer Details Not Avilable!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
	}

	@GetMapping("/customers")
	public ResponseEntity<List<Customer>> getAllCustomers() {
		List<Customer> customers = customerDao.getAllCustomers();
		if (customers == null || customers.isEmpty()) {
			return new ResponseEntity("Sorry! Customer Details Not Avilable!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
	}

	@PutMapping("/customers")
	public ResponseEntity<List<Customer>> updateCustomer(@RequestBody Customer customer) {
		List<Customer> customers = customerDao.updateCustomer(customer);

		if (customers == null || customers.isEmpty()) {
			return new ResponseEntity("Sorry! Customer details not updated!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
	}

	@DeleteMapping("/customers/{customerId}")
	public ResponseEntity<List<Customer>> deleteCustomer(@PathVariable("customerId") int customerId) {
		List<Customer> customers = customerDao.deleteCustomer(customerId);
		if (customers == null || customers.isEmpty()) {
			return new ResponseEntity("Sorry! Customer ID not available!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
	}

	@GetMapping("/customers/{customerId}")
	public ResponseEntity<Customer> findEmployee(@PathVariable("customerId") int customerId) {
		Customer customer = customerDao.findCustomer(customerId);
		if (customer == null) {
			return new ResponseEntity("Sorry! Customer ID Not Found!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<Customer>(customer, HttpStatus.OK);
	}

}
