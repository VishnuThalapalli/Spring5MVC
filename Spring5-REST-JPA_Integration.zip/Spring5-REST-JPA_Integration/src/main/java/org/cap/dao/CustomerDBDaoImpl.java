package org.cap.dao;

import java.util.List;
import java.util.ListIterator;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.Customer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("customerDbDao")
@Transactional
public class CustomerDBDaoImpl implements ICustomerDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Customer> getAllCustomers() {

		return entityManager.createQuery("from Customer").getResultList();
	}

	@Override
	public List<Customer> createCustomer(Customer customer) {

		entityManager.persist(customer);
		return getAllCustomers();
	}

	@Override
	public List<Customer> updateCustomer(Customer customer) {
		boolean flag = false;
		ListIterator<Customer> iterator = entityManager.listIterator();
		while (iterator.hasNext()) {
			Customer cust = iterator.next();
			if (cust.getCustomerId() == customer.getCustomerId()) {
				flag = true;
				iterator.set(customer);
			}
		}

		if (flag)
			return entityManager;
		else
			return null;
	}

	@Override
	public Customer findCustomer(int customerId) {
		for (Customer custf : entityManager) {
			if (customerId == custf.getCustomerId())
				return custf;
		}
		return null;
	}

	@Override
	public List<Customer> deleteCustomer(int customerId) {
		Customer custo = findCustomer(customerId);
		if (custo != null) {
			entityManager.remove(findCustomer(customerId));
			return entityManager;
		}
		return null;
	}

}
