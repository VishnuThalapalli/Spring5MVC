package org.cap.mapkeymapping;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.model.Address;
import org.cap.model.Company;
import org.cap.model.Employee;

public class MapKeyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("capg");
		
		EntityManager entityManager=emf.createEntityManager();
		
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
		 Department d = new Department();
		    d.setName("Design");

		    Person p1 = new Person("Tom");
		    p1.setDepartment(d);

		    Person p2 = new Person("Jack");
		    p2.setDepartment(d);
		    
		    d.getPersons().add(p1);
		    d.getPersons().add(p2);
		    
		    entityManager.persist(p1);
		    entityManager.persist(p2);
		    entityManager.persist(d);   			
			
		transaction.commit();
		entityManager.close();
		emf.close();
	
	}

}
