package org.cap.manytomanymap;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.model.Address;
import org.cap.model.Company;
import org.cap.model.Employee;

public class MainMappingManytoMany {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("capg");
		
		EntityManager entityManager=emf.createEntityManager();
		
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
			
		Student st1=new Student(1,"Vipul",null);  
        Student st2=new Student(2,"Vimal",null);  
          
        entityManager.merge(st1);  
        entityManager.merge(st2);  
          
        ArrayList<Student> al1=new ArrayList<Student>();  
        ArrayList<Student> al2=new ArrayList<Student>();  
          
        al1.add(st1);  
        al1.add(st2);  
          
        al2.add(st1);  
        al2.add(st2);  
          
        Library lib1=new Library(101,"Data Structure",al1);  
        Library lib2=new Library(102,"DBMS",al2);  
          
          
        entityManager.merge(lib1);  
        entityManager.merge(lib2);  
          			
			
		transaction.commit();
		entityManager.close();
		emf.close();
	
	}

}
