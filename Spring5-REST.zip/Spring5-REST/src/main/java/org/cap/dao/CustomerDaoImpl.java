package org.cap.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.model.Account;
import org.cap.model.Customer;

import org.springframework.stereotype.Repository;

@Repository("customerDao")
public class CustomerDaoImpl implements ICustomerDao {
	private static AtomicInteger customerId = new AtomicInteger(1);
	private static AtomicInteger accountNo = new AtomicInteger(1000);
	private static List<Customer> customerDummyDb = dummyDB();

	private static List<Customer> dummyDB() {
		List<Customer> customers = new ArrayList<>();
		customers.add(new Customer(customerId.getAndIncrement(), "TOm", "32434324",
				new Account(accountNo.getAndIncrement(), "Savings", LocalDate.of(2000, 2, 12), 23000)));

		customers.add(new Customer(customerId.getAndIncrement(), "Thomson", "8676889",
				new Account(accountNo.getAndIncrement(), "Savings", LocalDate.of(2020, 3, 21), 3000)));

		customers.add(new Customer(customerId.getAndIncrement(), "Alwin", "6787878",
				new Account(accountNo.getAndIncrement(), "Current", LocalDate.of(2020, 2, 11), 5600)));

		customers.add(new Customer(customerId.getAndIncrement(), "Jack", "4535435", null));

		customers.add(new Customer(customerId.getAndIncrement(), "Ram", "422222", null));
		customers.add(new Customer(customerId.getAndIncrement(), "Akash", "322222", null));
		customers.add(new Customer(customerId.getAndIncrement(), "Bachan", "111222", null));
		customers.add(new Customer(customerId.getAndIncrement(), "Madhav", "6432222", null));

		return customers;
	}

	@Override
	public List<Customer> getAllCustomers() {

		return customerDummyDb;
	}

	@Override
	public List<Customer> createCustomer(Customer customer) {
		customerDummyDb.add(customer);
		return customerDummyDb;
	}

	@Override
	public List<Customer> updateCustomer(Customer customer) {
		boolean flag = false;
		ListIterator<Customer> iterator = customerDummyDb.listIterator();
		while (iterator.hasNext()) {
			Customer cust = iterator.next();
			if (cust.getCustomerId() == customer.getCustomerId()) {
				flag = true;
				iterator.set(customer);
			}
		}

		if (flag)
			return customerDummyDb;
		else
			return null;
	}

	@Override
	public Customer findCustomer(int customerId) {
		for (Customer custf : customerDummyDb) {
			if (customerId == custf.getCustomerId())
				return custf;
		}
		return null;
	}

	@Override
	public List<Customer> deleteCustomer(int customerId) {
		Customer custo = findCustomer(customerId);
		if (custo != null) {
			customerDummyDb.remove(findCustomer(customerId));
			return customerDummyDb;
		}
		return null;
	}

}
