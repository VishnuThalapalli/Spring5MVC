package org.cap.jpql;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.cap.criteria.JPA_Practice.Employee;

public class Sorting {

	public static void main(String args[]) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Emp_details");
		EntityManager em = emf.createEntityManager();

		// new born enity object
		Employee emp1 = new Employee(21, "Jaman", 26);

		Employee emp2 = new Employee(13, "Saurav", 21);

		Employee emp3 = new Employee(15, "Alam", 28);

		em.getTransaction().begin();
		// managed state
		em.persist(emp1);
		em.persist(emp2);
		em.persist(emp3);

		Query q1 = em.createQuery("Select e from Employee e order by e.emp_age asc");

		@SuppressWarnings("unchecked")
		List<Employee> l1 = (List<Employee>) q1.getResultList();

		System.out.print("emp_id");
		System.out.print("\t emp_name");
		System.out.println("\t emp_age");

		for (Employee s : l1) {
			System.out.print(s.getEmp_id());
			System.out.print("\t" + s.getEmp_name());
			System.out.println("\t" + s.getEmp_age());
		}

		Query q2 = em.createQuery("Select e from Employee e order by e.emp_age desc");

		@SuppressWarnings("unchecked")
		List<Employee> l2 = (List<Employee>) q2.getResultList();

		System.out.print("emp_id");
		System.out.print("\t emp_name");
		System.out.println("\t emp_age");

		for (Employee s : l2) {
			System.out.print(s.getEmp_id());
			System.out.print("\t" + s.getEmp_name());
			System.out.println("\t" + s.getEmp_age());
		}

		em.getTransaction().commit();
		em.close();
		emf.close();
	}

}
