package org.cap.jpql;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.cap.criteria.JPA_Practice.Employee;

public class Aggregate {

	public static void main(String args[]) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Emp_details");
		EntityManager em = emf.createEntityManager();

		// new born enity object
		Employee emp1 = new Employee(21, "Jaman", 26);

		Employee emp2 = new Employee(13, "Saurav", 21);

		Employee emp3 = new Employee(15, "Alam", 28);

		em.getTransaction().begin();
		// managed state
		em.persist(emp1);
		em.persist(emp2);
		em.persist(emp3);

		Query q1 = em.createQuery("Select count(e) from Employee e");
		System.out.println("Number of Employees : " + q1.getSingleResult());

		Query q2 = em.createQuery("Select MAX(e.emp_age) from Employee e");
		System.out.println("Maximum age : " + q2.getSingleResult());

		Query q3 = em.createQuery("Select MIN(e.emp_age) from Employee e");
		System.out.println("Minimum age : " + q3.getSingleResult());
		em.getTransaction().commit();
		em.close();
		emf.close();
	}
}
