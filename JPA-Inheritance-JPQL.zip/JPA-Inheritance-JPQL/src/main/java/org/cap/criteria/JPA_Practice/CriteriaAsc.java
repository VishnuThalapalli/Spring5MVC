package org.cap.criteria.JPA_Practice;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.List;

public class CriteriaAsc {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Emp_details");
		EntityManager em = emf.createEntityManager();

		// new born enity object
		Employee emp1 = new Employee(11, "Jerry", 23);

		Employee emp2 = new Employee(12, "Smith", 22);

		Employee emp3 = new Employee(13, "George", 24);

		em.getTransaction().begin();
		// managed state
		em.persist(emp1);
		em.persist(emp2);
		em.persist(emp3);

		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Employee> cq = cb.createQuery(Employee.class);

		Root<Employee> stud = cq.from(Employee.class);

		cq.orderBy(cb.asc(stud.get("emp_age")));
		CriteriaQuery<Employee> select = cq.select(stud);
		TypedQuery<Employee> q = em.createQuery(select);
		List<Employee> list = q.getResultList();

		System.out.print("s_id");
		System.out.print("\t s_name");
		System.out.println("\t s_age");

		for (Employee s : list) {
			System.out.print(s.getEmp_id());
			System.out.print("\t" + s.getEmp_name());
			System.out.println("\t" + s.getEmp_age());
		}

		em.getTransaction().commit();
		em.close();
		emf.close();

	}
}
