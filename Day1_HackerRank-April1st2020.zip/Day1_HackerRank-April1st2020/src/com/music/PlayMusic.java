package com.music;

import java.util.Arrays;
import java.util.Scanner;

public class PlayMusic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scr = new Scanner(System.in);
		int indexNo = scr.nextInt();
		String[] songList = null;
		if (indexNo > 100) {
			songList = new String[100];
		} else {
			songList = new String[indexNo];
		}
		for (int i = 0; i < songList.length; i++) {
			songList[i] = scr.next();
		}
		int currentIndex = scr.nextInt();
		String nextSongToPlay = scr.next();
		int nextSongIndex = Arrays.asList(songList).indexOf(nextSongToPlay);
		if (!(nextSongIndex < 0) && nextSongIndex > currentIndex) {
			System.out.println(nextSongIndex - currentIndex);
		} else if (!(nextSongIndex < 0) && nextSongIndex < currentIndex) {
			System.out.println(currentIndex - nextSongIndex);
		}
		scr.close();
	}

}
