package com.inherit;

public class WagonR extends Car {

	public boolean isSedan;
	public String seats;
	public String mileage;
	
	public WagonR(boolean isSedan, String seats, String mileage) {
		super(isSedan,seats);
		this.isSedan = isSedan;
		this.seats = seats;
		this.mileage=mileage;
	}

	@Override
	public String getMileage() {
		return this.mileage;
	}

	

}
